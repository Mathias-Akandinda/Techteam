document.getElementById("nav01").innerHTML =
 "<ul id='menu'>" +
"<a href='index.html'>HOME</a> " +
 "<a href='About.html'>ABOUT US</a> " +
 "<a href='Admin.html'>ADMIN</a> " +
 "<a href='News.html'>NEWS</a> " +
 "<a href='Form.html'>CONTACT US</a> " +
  "<a href='projects.html'>PROJECTS</a> " +
 "<a href='Donate.html'>DONATE</a>  " +
 "<a href='faqs.html'>FAQs</a> " +

 "</ul>"; 
 